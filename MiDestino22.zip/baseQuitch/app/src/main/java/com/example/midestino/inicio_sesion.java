package com.example.midestino;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class inicio_sesion extends AppCompatActivity {
         Button btn2;

    private Button Iniciarsesion;
    private TextView contraseña, textingresa;
    private EditText user, Contraseña;
    private CheckBox recordar;
    String URL_SERVIDOR = "http://10.0.2.2/canchas/login.php";
    float v = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);
        btn2 = findViewById(R.id.verd);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(inicio_sesion.this, registrarte.class);
                startActivity(intent1);
            }
        });
    }


    public void irface(View view) {

            Intent i = new Intent(android.content.Intent.ACTION_VIEW,
                    Uri.parse("https://es-la.facebook.com/"));
            startActivity(i);
        }

    public void login(View view) {
        Intent intent = new Intent(inicio_sesion.this, MainActivity.class);
        startActivity(intent);
    }

    public void regist(View view) {
        Intent intent1 = new Intent(inicio_sesion.this, registrarte.class);
        startActivity(intent1);
    }

    public void goo(View view) {
        Intent i = new Intent(android.content.Intent.ACTION_VIEW,
                Uri.parse("https://mail.google.com/"));
        startActivity(i);

    }

    public void twi(View view) {
        Intent i = new Intent(android.content.Intent.ACTION_VIEW,
                Uri.parse("https://twitter.com/"));
        startActivity(i);
    }
}

